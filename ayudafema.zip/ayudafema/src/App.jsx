import { useState } from 'react'
import {
  ArrowRight,
  ArrowLeft,
  Camera,
  Upload,
  Check,
  FileText,
  Phone,
  ChevronDown,
  ChevronRight,
  Shield,
  Clock,
  MessageSquare,
  CheckCircle2
} from 'lucide-react'

const copy = {
  es: {
    partnerName: 'Ayuda Legal PR',
    builtBy: 'Construido por La Mano',
    free: 'Gratuito · Sin fines de lucro',
    demo: 'Prototipo — datos de demostración',
    back: 'Atrás',
    disclaimer: 'Herramienta independiente. No afiliada con FEMA ni con el gobierno federal.',

    landing: {
      eyebrow: 'Apelaciones de FEMA',
      headline: '¿FEMA te negó\nayuda?',
      sub: 'Podemos ayudarte a apelar. Gratis. En 15 minutos, con una foto de tu carta.',
      cta: 'Empezar',
      note: 'Leemos tu carta, preparamos la apelación, y te decimos exactamente qué enviar a FEMA.',
      phoneLabel: '¿Prefieres hablar con alguien?',
      phone: '1-800-981-5342'
    },

    upload: {
      step: 'Paso 1 de 5',
      headline: 'Sube tu carta\nde negación',
      sub: 'Una foto desde tu celular está bien. PDF también.',
      dropTitle: 'Toma una foto o sube un archivo',
      dropSub: 'Lee automáticamente la carta en inglés o español',
      camera: 'Tomar foto',
      upload: 'Subir archivo',
      reassure: 'Tus documentos son privados. Nadie más los ve.',
      demo: 'Usar carta de demostración'
    },

    processing: {
      headline: 'Leyendo tu carta…',
      sub: 'Esto tarda unos 20 segundos.',
      tasks: [
        'Identificando el número de caso',
        'Encontrando la razón de la negación',
        'Calculando el plazo de apelación',
        'Revisando qué evidencia necesitas'
      ]
    },

    diagnosis: {
      step: 'Paso 2 de 5',
      headline: 'Esto es lo\nque encontramos',
      caseLabel: 'Tu caso',
      disasterLabel: 'El desastre',
      reasonLabel: 'Razón de la negación',
      deadlineLabel: 'Plazo para apelar',
      daysLeft: 'días restantes',
      deadlineDate: 'vence el',
      reasonPlain: 'FEMA dice que no probaste ser dueño de la casa.',
      reasonContext:
        'Esta es la negación más común en Puerto Rico. El 35% de las casas no tienen título formal. Es apelable, y FEMA acepta otras formas de probar que la casa es tuya — no necesitas una escritura.',
      appealableBadge: 'Apelable',
      cta: 'Prepara mi apelación'
    },

    evidence: {
      step: 'Paso 3 de 5',
      headline: 'Necesitamos\nestas cosas',
      sub: 'Para tu tipo de negación, esta evidencia es lo que convence a FEMA. Te ayudamos con cada una.',
      items: [
        {
          title: 'Foto de tu casa',
          desc: 'Exterior y cualquier daño. Fotos de tu celular sirven.',
          why: 'Muestra que la casa existe y que tú tienes acceso a ella. FEMA acepta fotos con fecha.'
        },
        {
          title: 'Un recibo con tu nombre y dirección',
          desc: 'Luz, agua, internet, o cualquier cuenta reciente.',
          why: 'Prueba que tú vives en esa casa. No tiene que ser escritura — un recibo con tu nombre basta.'
        },
        {
          title: 'Carta del alcalde o junta comunitaria',
          desc: 'Si no tienes recibo, una carta del municipio funciona.',
          why: 'FEMA acepta cartas oficiales del municipio que confirmen que tú vives ahí. Te damos el modelo para pedírsela.'
        },
        {
          title: 'Declaración jurada de un vecino',
          desc: 'Un vecino firma diciendo que tú vives ahí. Te damos la plantilla.',
          why: 'Desde 2021, FEMA acepta declaraciones juradas cuando no hay escritura. Esta es tu red de seguridad.'
        }
      ],
      optional: 'Opcional — pero ayuda',
      addButton: 'Subir',
      done: 'Listo',
      template: 'Ver plantilla',
      cta: 'Lo tengo todo',
      skipLater: 'Puedo subirlo más tarde'
    },

    draft: {
      step: 'Paso 4 de 5',
      headline: 'Tu apelación\nestá lista',
      sub: 'Revisada por un abogado de Ayuda Legal PR. Lista para enviar a FEMA.',
      reviewBadge: 'Revisado por abogado',
      previewLabel: 'Vista previa de la carta',
      switchTo: 'Ver en inglés',
      cta: 'Enviar a FEMA',
      disclaimer:
        'La apelación se envía en inglés porque FEMA procesa más rápido en inglés. Guardamos la versión en español para ti.'
    },

    submit: {
      step: 'Paso 5 de 5',
      headline: 'Envía la apelación\na FEMA',
      sub: 'Tres maneras. Escoge la que te sirva.',
      methods: [
        {
          title: 'Por internet',
          badge: 'Más rápido',
          steps: [
            'Entra a disasterassistance.gov',
            'Inicia sesión con tu cuenta',
            'Ve a "Correspondence" (Correspondencia)',
            'Sube el archivo que te damos',
            'Toca "Submit"'
          ],
          cta: 'Descargar archivo'
        },
        {
          title: 'Por correo',
          badge: 'Si prefieres papel',
          steps: [
            'Imprime la carta y la evidencia',
            'Métela en un sobre con la etiqueta que te damos',
            'Llévala al correo antes del plazo'
          ],
          cta: 'Descargar sobre y etiqueta'
        },
        {
          title: 'Por fax',
          badge: 'Opción tradicional',
          steps: [
            'Usa el fax del Centro de Recuperación más cercano',
            'El número de fax viene en el archivo que te damos'
          ],
          cta: 'Ver números de fax'
        }
      ],
      confirm: 'Ya la envié',
      help: '¿Necesitas ayuda? Llámanos: 1-800-981-5342'
    },

    tracking: {
      step: 'Listo',
      headline: 'Enviado',
      sub: 'FEMA tiene 90 días para responder. Te avisamos por mensaje de texto cuando haya novedades.',
      submittedLabel: 'Enviado el',
      submittedDate: '18 de abril, 2026',
      expectedLabel: 'Respuesta esperada',
      expectedDate: 'antes del 17 de julio, 2026',
      caseLabel: 'Tu número de caso',
      smsLabel: 'Recordatorios por SMS',
      smsValue: '+1 787 ••• •• 42',
      nextSteps: '¿Qué sigue?',
      stepsList: [
        'FEMA revisa la apelación (30–90 días)',
        'Si aprueban, te envían el dinero',
        'Si piden más información, te avisamos',
        'Si niegan otra vez, podemos preparar una segunda apelación'
      ],
      another: 'Ayudar a alguien más'
    }
  },
  en: {
    partnerName: 'Ayuda Legal PR',
    builtBy: 'Built by La Mano',
    free: 'Free · Nonprofit',
    demo: 'Prototype — demo data',
    back: 'Back',
    disclaimer: 'Independent tool. Not affiliated with FEMA or the federal government.',

    landing: {
      eyebrow: 'FEMA appeals',
      headline: 'Did FEMA\ndeny your aid?',
      sub: 'We can help you appeal. Free. In 15 minutes, with one photo of your letter.',
      cta: 'Get started',
      note: 'We read your letter, prepare the appeal, and tell you exactly what to send to FEMA.',
      phoneLabel: 'Rather talk to someone?',
      phone: '1-800-981-5342'
    },

    upload: {
      step: 'Step 1 of 5',
      headline: 'Upload your\ndenial letter',
      sub: 'A photo from your phone is fine. PDF works too.',
      dropTitle: 'Take a photo or upload a file',
      dropSub: 'We read letters in English or Spanish automatically',
      camera: 'Take photo',
      upload: 'Upload file',
      reassure: 'Your documents are private. No one else sees them.',
      demo: 'Use demo letter'
    },

    processing: {
      headline: 'Reading your letter…',
      sub: 'This takes about 20 seconds.',
      tasks: [
        'Finding the case number',
        'Identifying denial reason',
        'Calculating appeal deadline',
        'Checking what evidence you need'
      ]
    },

    diagnosis: {
      step: 'Step 2 of 5',
      headline: "Here's what\nwe found",
      caseLabel: 'Your case',
      disasterLabel: 'The disaster',
      reasonLabel: 'Reason for denial',
      deadlineLabel: 'Appeal deadline',
      daysLeft: 'days left',
      deadlineDate: 'due',
      reasonPlain: "FEMA says you didn't prove you own the house.",
      reasonContext:
        "This is the most common denial in Puerto Rico. 35% of homes don't have formal title. It's appealable, and FEMA accepts other ways to prove ownership — you don't need a deed.",
      appealableBadge: 'Appealable',
      cta: 'Prepare my appeal'
    },

    evidence: {
      step: 'Step 3 of 5',
      headline: 'We need\nthese things',
      sub: "For your denial type, this evidence is what convinces FEMA. We'll walk you through each one.",
      items: [
        {
          title: 'A photo of your house',
          desc: 'Exterior and any damage. Phone photos work.',
          why: 'Shows the house exists and you have access to it. FEMA accepts timestamped photos.'
        },
        {
          title: 'A bill with your name and address',
          desc: 'Electric, water, internet, or any recent account.',
          why: "Proves you live there. Doesn't need to be a deed — a bill with your name is enough."
        },
        {
          title: 'Letter from the mayor or community board',
          desc: "If you don't have a bill, a letter from the municipio works.",
          why: 'FEMA accepts official letters from the municipio confirming you live there. We give you the template to request it.'
        },
        {
          title: "Neighbor's sworn statement",
          desc: 'A neighbor signs saying you live there. We provide the template.',
          why: "Since 2021, FEMA accepts sworn statements when there's no deed. This is your safety net."
        }
      ],
      optional: 'Optional — but helps',
      addButton: 'Upload',
      done: 'Done',
      template: 'See template',
      cta: 'I have everything',
      skipLater: 'I can upload later'
    },

    draft: {
      step: 'Step 4 of 5',
      headline: 'Your appeal\nis ready',
      sub: 'Reviewed by an Ayuda Legal PR attorney. Ready to send to FEMA.',
      reviewBadge: 'Attorney-reviewed',
      previewLabel: 'Letter preview',
      switchTo: 'Ver en español',
      cta: 'Send to FEMA',
      disclaimer:
        'Appeals are sent in English because FEMA processes English faster. We keep the Spanish version for you.'
    },

    submit: {
      step: 'Step 5 of 5',
      headline: 'Send the appeal\nto FEMA',
      sub: 'Three ways. Pick what works for you.',
      methods: [
        {
          title: 'Online',
          badge: 'Fastest',
          steps: [
            'Go to disasterassistance.gov',
            'Log in to your account',
            'Go to "Correspondence"',
            'Upload the file we give you',
            'Tap "Submit"'
          ],
          cta: 'Download file'
        },
        {
          title: 'By mail',
          badge: 'Paper option',
          steps: [
            'Print the letter and evidence',
            'Put it in an envelope with the label we provide',
            'Mail it before the deadline'
          ],
          cta: 'Download envelope & label'
        },
        {
          title: 'By fax',
          badge: 'Traditional',
          steps: [
            'Use the fax at the nearest Recovery Center',
            'The fax number is in the file we give you'
          ],
          cta: 'See fax numbers'
        }
      ],
      confirm: "I've sent it",
      help: 'Need help? Call us: 1-800-981-5342'
    },

    tracking: {
      step: 'Done',
      headline: 'Sent',
      sub: 'FEMA has 90 days to respond. We text you when there are updates.',
      submittedLabel: 'Submitted',
      submittedDate: 'April 18, 2026',
      expectedLabel: 'Response expected',
      expectedDate: 'by July 17, 2026',
      caseLabel: 'Your case number',
      smsLabel: 'SMS reminders',
      smsValue: '+1 787 ••• •• 42',
      nextSteps: "What's next?",
      stepsList: [
        'FEMA reviews the appeal (30–90 days)',
        'If approved, they send the funds',
        "If they need more info, we'll let you know",
        'If denied again, we can prepare a second appeal'
      ],
      another: 'Help someone else'
    }
  }
}

const demoCase = {
  applicant: 'María R.',
  caseId: '4671-7214893',
  disasterCode: 'DR-4671-PR',
  disasterName: 'Huracán Fiona (2022)',
  deadlineDays: 47,
  deadlineDateEs: '4 de junio de 2026',
  deadlineDateEn: 'June 4, 2026'
}

export default function App() {
  const [step, setStep] = useState('landing')
  const [lang, setLang] = useState('es')
  const [appealLang, setAppealLang] = useState('en')
  const [evidence, setEvidence] = useState([false, false, false, false])
  const [expandedEvidence, setExpandedEvidence] = useState(null)
  const t = copy[lang]

  const startProcessing = () => {
    setStep('processing')
    setTimeout(() => setStep('diagnosis'), 2400)
  }

  const toggleEvidence = (i) => {
    const next = [...evidence]
    next[i] = !next[i]
    setEvidence(next)
  }

  const evidenceDone = evidence.filter(Boolean).length

  const navOrder = ['landing', 'upload', 'processing', 'diagnosis', 'evidence', 'draft', 'submit', 'tracking']
  const currentIdx = navOrder.indexOf(step)
  const canBack = currentIdx > 0 && step !== 'processing'
  const goBack = () => {
    if (step === 'diagnosis') setStep('upload')
    else setStep(navOrder[Math.max(0, currentIdx - 1)])
  }

  return (
    <div className="hog-app hog-grain">
      <div className="px-6 md:px-10 pt-6 md:pt-8 pb-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          {canBack ? (
            <button onClick={goBack} className="hog-btn-ghost text-sm flex items-center gap-1.5">
              <ArrowLeft size={14} /> {t.back}
            </button>
          ) : (
            <div className="text-xs tracking-wide uppercase" style={{ color: 'var(--ink-softer)' }}>
              {t.partnerName}
            </div>
          )}
        </div>
        <div className="flex items-center gap-4 text-xs">
          <span className="uppercase tracking-widest hidden md:inline" style={{ color: 'var(--ink-softer)' }}>
            {t.demo}
          </span>
          <button onClick={() => setLang(lang === 'es' ? 'en' : 'es')} className="hog-btn-ghost uppercase tracking-widest">
            {lang === 'es' ? 'EN' : 'ES'}
          </button>
        </div>
      </div>

      <main className="px-6 md:px-10 pb-24 max-w-[640px] mx-auto">
        {step === 'landing' && <Landing t={t} onStart={() => setStep('upload')} />}
        {step === 'upload' && <UploadStep t={t} onContinue={startProcessing} />}
        {step === 'processing' && <Processing t={t} />}
        {step === 'diagnosis' && <Diagnosis t={t} lang={lang} onContinue={() => setStep('evidence')} />}
        {step === 'evidence' && (
          <Evidence
            t={t}
            evidence={evidence}
            toggle={toggleEvidence}
            expanded={expandedEvidence}
            setExpanded={setExpandedEvidence}
            done={evidenceDone}
            onContinue={() => setStep('draft')}
          />
        )}
        {step === 'draft' && (
          <Draft t={t} appealLang={appealLang} setAppealLang={setAppealLang} onContinue={() => setStep('submit')} />
        )}
        {step === 'submit' && <Submit t={t} onContinue={() => setStep('tracking')} />}
        {step === 'tracking' && (
          <Tracking
            t={t}
            lang={lang}
            onReset={() => {
              setStep('landing')
              setEvidence([false, false, false, false])
            }}
          />
        )}
      </main>

      <footer className="px-6 md:px-10 pb-10 max-w-[640px] mx-auto">
        <div className="hog-rule mb-5" />
        <div className="flex flex-wrap items-center justify-between gap-3 text-xs mb-2" style={{ color: 'var(--ink-softer)' }}>
          <span>{t.free}</span>
          <span className="uppercase tracking-widest">{t.builtBy}</span>
        </div>
        <div className="text-[10px]" style={{ color: 'var(--ink-softer)' }}>
          {t.disclaimer}
        </div>
      </footer>
    </div>
  )
}

function Landing({ t, onStart }) {
  return (
    <div className="hog-fade pt-12 md:pt-24">
      <div className="text-xs uppercase tracking-[0.2em] mb-8" style={{ color: 'var(--ink-softer)' }}>
        {t.landing.eyebrow}
      </div>

      <h1 className="hog-serif text-[56px] md:text-[88px] leading-[0.95] mb-8 whitespace-pre-line">
        {t.landing.headline}
      </h1>

      <p className="text-[19px] md:text-[21px] leading-[1.5] mb-12 max-w-[520px]" style={{ color: 'var(--ink-soft)' }}>
        {t.landing.sub}
      </p>

      <button onClick={onStart} className="hog-btn-primary inline-flex items-center gap-3 px-7 py-4 rounded-none text-[15px]">
        {t.landing.cta}
        <ArrowRight size={16} />
      </button>

      <div className="hog-rule mt-16 mb-6" />

      <p className="text-[14px] leading-relaxed mb-6" style={{ color: 'var(--ink-softer)' }}>
        {t.landing.note}
      </p>

      <div className="flex items-center gap-2 text-[14px]" style={{ color: 'var(--ink-soft)' }}>
        <Phone size={14} />
        <span>{t.landing.phoneLabel}</span>
        <a href={`tel:${t.landing.phone}`} className="underline underline-offset-4" style={{ color: 'var(--ink)' }}>
          {t.landing.phone}
        </a>
      </div>
    </div>
  )
}

function UploadStep({ t, onContinue }) {
  return (
    <div className="hog-fade pt-6 md:pt-12">
      <StepLabel text={t.upload.step} />
      <Headline text={t.upload.headline} />
      <p className="text-[18px] mb-10" style={{ color: 'var(--ink-soft)' }}>
        {t.upload.sub}
      </p>

      <div className="border border-dashed p-10 md:p-14 text-center mb-6" style={{ borderColor: 'var(--rule)' }}>
        <div className="flex flex-col items-center gap-4">
          <FileText size={28} strokeWidth={1.25} style={{ color: 'var(--ink-softer)' }} />
          <div className="hog-serif text-[24px] italic" style={{ color: 'var(--ink)' }}>
            {t.upload.dropTitle}
          </div>
          <div className="text-[13px]" style={{ color: 'var(--ink-softer)' }}>
            {t.upload.dropSub}
          </div>
          <div className="flex flex-col md:flex-row gap-3 mt-4 w-full md:w-auto">
            <button onClick={onContinue} className="hog-btn-primary inline-flex items-center justify-center gap-2 px-5 py-3 text-sm">
              <Camera size={14} /> {t.upload.camera}
            </button>
            <button
              onClick={onContinue}
              className="inline-flex items-center justify-center gap-2 px-5 py-3 text-sm border"
              style={{ borderColor: 'var(--ink)', color: 'var(--ink)' }}
            >
              <Upload size={14} /> {t.upload.upload}
            </button>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-2 text-[13px] mb-8" style={{ color: 'var(--ink-softer)' }}>
        <Shield size={13} /> {t.upload.reassure}
      </div>

      <button onClick={onContinue} className="hog-btn-ghost text-sm underline underline-offset-4">
        {t.upload.demo} →
      </button>
    </div>
  )
}

function Processing({ t }) {
  return (
    <div className="hog-fade pt-12 md:pt-32">
      <h1 className="hog-serif text-[40px] md:text-[56px] leading-[1] mb-4 italic">
        {t.processing.headline}
        <span className="hog-caret ml-1" />
      </h1>
      <p className="text-[16px] mb-12" style={{ color: 'var(--ink-soft)' }}>
        {t.processing.sub}
      </p>
      <ul className="space-y-4">
        {t.processing.tasks.map((task, i) => (
          <li key={i} className="flex items-center gap-3 text-[15px]" style={{ color: 'var(--ink-soft)' }}>
            <span
              className="hog-pulse"
              style={{
                display: 'inline-block',
                width: 6,
                height: 6,
                background: 'var(--accent)',
                borderRadius: '50%',
                animationDelay: `${i * 0.2}s`
              }}
            />
            {task}
          </li>
        ))}
      </ul>
    </div>
  )
}

function Diagnosis({ t, lang, onContinue }) {
  const deadlineDate = lang === 'es' ? demoCase.deadlineDateEs : demoCase.deadlineDateEn
  return (
    <div className="hog-fade pt-6 md:pt-12">
      <StepLabel text={t.diagnosis.step} />
      <Headline text={t.diagnosis.headline} />

      <div className="hog-rule mb-8" />

      <dl className="space-y-6 mb-10">
        <Row label={t.diagnosis.caseLabel} value={demoCase.caseId} mono />
        <Row label={t.diagnosis.disasterLabel} value={`${demoCase.disasterName} · ${demoCase.disasterCode}`} />
        <div>
          <dt className="text-xs uppercase tracking-widest mb-2" style={{ color: 'var(--ink-softer)' }}>
            {t.diagnosis.reasonLabel}
          </dt>
          <dd className="text-[18px] mb-3" style={{ color: 'var(--ink)' }}>
            {t.diagnosis.reasonPlain}
          </dd>
          <dd className="text-[14px] leading-relaxed" style={{ color: 'var(--ink-soft)' }}>
            {t.diagnosis.reasonContext}
          </dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-widest mb-2" style={{ color: 'var(--ink-softer)' }}>
            {t.diagnosis.deadlineLabel}
          </dt>
          <dd className="flex items-baseline gap-3">
            <span className="hog-serif text-[48px] leading-none" style={{ color: 'var(--ink)' }}>
              {demoCase.deadlineDays}
            </span>
            <span className="text-[14px]" style={{ color: 'var(--ink-soft)' }}>
              {t.diagnosis.daysLeft} · {t.diagnosis.deadlineDate} {deadlineDate}
            </span>
          </dd>
        </div>
      </dl>

      <div className="flex items-center gap-3 mb-10 px-4 py-3" style={{ background: 'var(--accent-soft)' }}>
        <div style={{ width: 6, height: 6, background: 'var(--accent)', borderRadius: '50%' }} />
        <span className="text-[13px] uppercase tracking-widest" style={{ color: 'var(--accent)' }}>
          {t.diagnosis.appealableBadge}
        </span>
      </div>

      <button onClick={onContinue} className="hog-btn-primary inline-flex items-center gap-3 px-7 py-4 text-[15px]">
        {t.diagnosis.cta}
        <ArrowRight size={16} />
      </button>
    </div>
  )
}

function Evidence({ t, evidence, toggle, expanded, setExpanded, done, onContinue }) {
  return (
    <div className="hog-fade pt-6 md:pt-12">
      <StepLabel text={t.evidence.step} />
      <Headline text={t.evidence.headline} />
      <p className="text-[17px] mb-10 leading-relaxed" style={{ color: 'var(--ink-soft)' }}>
        {t.evidence.sub}
      </p>

      <div className="space-y-1 mb-10">
        {t.evidence.items.map((item, i) => {
          const isDone = evidence[i]
          const isOpen = expanded === i
          return (
            <div key={i}>
              <div className="flex items-start gap-4 py-5 border-t" style={{ borderColor: 'var(--rule)' }}>
                <button onClick={() => toggle(i)} className="mt-1 flex-shrink-0" aria-label="Toggle">
                  {isDone ? (
                    <div
                      className="w-5 h-5 rounded-full flex items-center justify-center"
                      style={{ background: 'var(--ok)', color: 'var(--paper)' }}
                    >
                      <Check size={12} strokeWidth={3} />
                    </div>
                  ) : (
                    <div className="w-5 h-5 rounded-full border" style={{ borderColor: 'var(--ink-softer)' }} />
                  )}
                </button>
                <div className="flex-1">
                  <div className="flex items-start justify-between gap-4 mb-1">
                    <div
                      className="hog-serif text-[22px] leading-tight"
                      style={{
                        color: isDone ? 'var(--ink-softer)' : 'var(--ink)',
                        textDecoration: isDone ? 'line-through' : 'none'
                      }}
                    >
                      {item.title}
                    </div>
                    <button
                      onClick={() => setExpanded(isOpen ? null : i)}
                      className="hog-btn-ghost text-xs uppercase tracking-widest flex items-center gap-1 mt-1 flex-shrink-0"
                    >
                      {isOpen ? <ChevronDown size={12} /> : (<>¿Por qué? <ChevronRight size={12} /></>)}
                    </button>
                  </div>
                  <div className="text-[14px] leading-relaxed mb-3" style={{ color: 'var(--ink-soft)' }}>
                    {item.desc}
                  </div>
                  {isOpen && (
                    <div
                      className="hog-fade text-[13px] leading-relaxed p-4 mb-3"
                      style={{ background: 'var(--paper-edge)', color: 'var(--ink-soft)' }}
                    >
                      {item.why}
                    </div>
                  )}
                  <div className="flex gap-4 text-[12px] uppercase tracking-widest">
                    {!isDone ? (
                      <button onClick={() => toggle(i)} className="hog-btn-ghost flex items-center gap-1" style={{ color: 'var(--ink)' }}>
                        <Upload size={11} /> {t.evidence.addButton}
                      </button>
                    ) : (
                      <span style={{ color: 'var(--ok)' }}>{t.evidence.done}</span>
                    )}
                    {i >= 2 && (
                      <button className="hog-btn-ghost flex items-center gap-1">
                        <FileText size={11} /> {t.evidence.template}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )
        })}
        <div className="hog-rule" />
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-start md:items-center">
        <button onClick={onContinue} disabled={done < 2} className="hog-btn-primary inline-flex items-center gap-3 px-7 py-4 text-[15px] disabled:opacity-30">
          {t.evidence.cta}
          <ArrowRight size={16} />
        </button>
        <button onClick={onContinue} className="hog-btn-ghost text-sm underline underline-offset-4">
          {t.evidence.skipLater}
        </button>
      </div>

      {done < 2 && (
        <div className="mt-4 text-[12px]" style={{ color: 'var(--ink-softer)' }}>
          {done}/4
        </div>
      )}
    </div>
  )
}

function Draft({ t, appealLang, setAppealLang, onContinue }) {
  const letterEn = `Registration Number: ${demoCase.caseId}

U.S. Department of Homeland Security
Federal Emergency Management Agency
National Processing Service Center
P.O. Box 10055
Hyattsville, MD 20782-7055

Re:  Appeal of Ineligibility Determination
     Disaster: ${demoCase.disasterCode} — ${demoCase.disasterName}
     Applicant: María R.
     Denial Reason: Ownership Not Verified

Dear FEMA Appeals Officer:

I am writing to appeal FEMA's determination that I
have not established ownership of my primary residence
at the address of record. I respectfully request that
this determination be reversed based on the supporting
documentation enclosed herewith.

The property in question has been in my family since
1961, passed to me upon the death of my father in
2014. No formal transfer of title was executed at that
time, consistent with customary practice for intra-
family transfers in rural Puerto Rico. As recognized
in FEMA's 2021 guidance on informal homeownership
(DRRA §1212; 86 Fed. Reg. 31,553), alternative
documentation is sufficient to establish ownership
where a formal deed is unavailable.

In support of this appeal I enclose:

    1. Photographs of the residence showing exterior
       and storm-related damage, timestamped.
    2. Electric service bill in the applicant's name
       at the address of record, dated March 2026.
    3. Letter from the Municipal Office of Yabucoa
       confirming continuous residence at the address.
    4. Sworn statement from adjacent neighbor,
       notarized, attesting to ownership and occupancy
       since 2014.

This documentation is consistent with the categories
of proof FEMA is authorized to accept under 44 C.F.R.
§ 206.111 and the Individual Assistance Program and
Policy Guide (IAPPG) v1.1, §V.D.1.

I respectfully request that the determination of
ineligibility be reversed and that my application be
restored to active review for Housing Assistance
under the Individuals and Households Program.

Respectfully submitted,

___________________________
María R.
Date: ____________________

Enclosures: (4)
cc: Ayuda Legal Puerto Rico`

  const letterEs = `Número de registro: ${demoCase.caseId}

Departamento de Seguridad Nacional de los EE. UU.
Agencia Federal para el Manejo de Emergencias (FEMA)
National Processing Service Center
P.O. Box 10055
Hyattsville, MD 20782-7055

Asunto:  Apelación de determinación de inelegibilidad
         Desastre: ${demoCase.disasterCode} — ${demoCase.disasterName}
         Solicitante: María R.
         Razón de negación: Titularidad no verificada

Estimado oficial de apelaciones de FEMA:

Escribo para apelar la determinación de FEMA según la
cual no he establecido la titularidad de mi residencia
principal en la dirección registrada. Respetuosamente
solicito que se revoque dicha determinación con base
en la documentación adjunta.

La propiedad en cuestión ha estado en mi familia desde
1961 y pasó a mi nombre al fallecimiento de mi padre
en 2014. No se ejecutó un traspaso formal del título
en ese momento, conforme a la práctica consuetudinaria
para transferencias intrafamiliares en zonas rurales
de Puerto Rico. Como lo reconoce la guía de FEMA
de 2021 sobre titularidad informal (DRRA §1212;
86 Fed. Reg. 31,553), se acepta documentación
alternativa cuando no existe una escritura formal.

En apoyo de esta apelación incluyo:

    1. Fotografías de la residencia mostrando el
       exterior y los daños por el huracán, con fecha.
    2. Recibo de servicio eléctrico a nombre de la
       solicitante en la dirección registrada,
       marzo de 2026.
    3. Carta de la Oficina Municipal de Yabucoa que
       confirma residencia continua en la dirección.
    4. Declaración jurada de vecino colindante,
       notarizada, que da fe de la titularidad y
       ocupación desde 2014.

Esta documentación es consistente con las categorías
de prueba que FEMA está autorizada a aceptar bajo
44 C.F.R. § 206.111 y la Guía de Programa y Política
de Asistencia Individual (IAPPG) v1.1, §V.D.1.

Solicito respetuosamente que se revoque la
determinación de inelegibilidad y que mi solicitud
sea restaurada a revisión activa bajo el Programa
de Individuos y Hogares.

Respetuosamente,

___________________________
María R.
Fecha: ____________________

Anexos: (4)
cc: Ayuda Legal Puerto Rico`

  return (
    <div className="hog-fade pt-6 md:pt-12">
      <StepLabel text={t.draft.step} />
      <Headline text={t.draft.headline} />
      <p className="text-[17px] mb-6" style={{ color: 'var(--ink-soft)' }}>
        {t.draft.sub}
      </p>

      <div className="flex items-center gap-3 mb-8">
        <div
          className="inline-flex items-center gap-2 px-3 py-1.5 text-[11px] uppercase tracking-widest"
          style={{ background: 'var(--ok)', color: 'var(--paper)' }}
        >
          <Shield size={11} /> {t.draft.reviewBadge}
        </div>
        <button
          onClick={() => setAppealLang(appealLang === 'en' ? 'es' : 'en')}
          className="hog-btn-ghost text-[12px] uppercase tracking-widest underline underline-offset-4"
        >
          {t.draft.switchTo}
        </button>
      </div>

      <div className="text-[11px] uppercase tracking-widest mb-3" style={{ color: 'var(--ink-softer)' }}>
        {t.draft.previewLabel}
      </div>

      <div className="hog-letter p-6 md:p-10 mb-6">
        <pre className="hog-mono text-[11px] md:text-[12px] leading-[1.6] whitespace-pre-wrap" style={{ color: 'var(--ink)' }}>
          {appealLang === 'en' ? letterEn : letterEs}
        </pre>
      </div>

      <p className="text-[12px] mb-8 leading-relaxed" style={{ color: 'var(--ink-softer)' }}>
        {t.draft.disclaimer}
      </p>

      <button onClick={onContinue} className="hog-btn-primary inline-flex items-center gap-3 px-7 py-4 text-[15px]">
        {t.draft.cta}
        <ArrowRight size={16} />
      </button>
    </div>
  )
}

function Submit({ t, onContinue }) {
  return (
    <div className="hog-fade pt-6 md:pt-12">
      <StepLabel text={t.submit.step} />
      <Headline text={t.submit.headline} />
      <p className="text-[17px] mb-10" style={{ color: 'var(--ink-soft)' }}>
        {t.submit.sub}
      </p>

      <div className="space-y-1 mb-10">
        {t.submit.methods.map((m, i) => (
          <div key={i} className="py-6 border-t" style={{ borderColor: 'var(--rule)' }}>
            <div className="flex items-baseline justify-between mb-3">
              <div className="hog-serif text-[26px]" style={{ color: 'var(--ink)' }}>
                {m.title}
              </div>
              <div className="text-[10px] uppercase tracking-widest" style={{ color: 'var(--ink-softer)' }}>
                {m.badge}
              </div>
            </div>
            <ol className="space-y-2 mb-4 ml-1">
              {m.steps.map((s, j) => (
                <li key={j} className="flex gap-3 text-[14px] leading-relaxed" style={{ color: 'var(--ink-soft)' }}>
                  <span className="hog-mono text-[12px] flex-shrink-0 mt-1" style={{ color: 'var(--ink-softer)' }}>
                    {String(j + 1).padStart(2, '0')}
                  </span>
                  <span>{s}</span>
                </li>
              ))}
            </ol>
            <button className="hog-btn-ghost text-[12px] uppercase tracking-widest underline underline-offset-4" style={{ color: 'var(--ink)' }}>
              {m.cta} →
            </button>
          </div>
        ))}
        <div className="hog-rule" />
      </div>

      <button onClick={onContinue} className="hog-btn-primary inline-flex items-center gap-3 px-7 py-4 text-[15px] mb-6">
        <CheckCircle2 size={16} /> {t.submit.confirm}
      </button>

      <div className="flex items-center gap-2 text-[13px]" style={{ color: 'var(--ink-softer)' }}>
        <Phone size={13} /> {t.submit.help}
      </div>
    </div>
  )
}

function Tracking({ t, lang, onReset }) {
  return (
    <div className="hog-fade pt-6 md:pt-12">
      <div className="text-xs uppercase tracking-[0.2em] mb-8" style={{ color: 'var(--ok)' }}>
        {t.tracking.step}
      </div>

      <h1 className="hog-serif text-[80px] md:text-[120px] leading-none mb-6" style={{ color: 'var(--ink)' }}>
        {t.tracking.headline}
        <span style={{ color: 'var(--ok)' }}>.</span>
      </h1>

      <p className="text-[18px] leading-relaxed mb-12 max-w-[480px]" style={{ color: 'var(--ink-soft)' }}>
        {t.tracking.sub}
      </p>

      <div className="hog-rule mb-8" />

      <dl className="space-y-6 mb-10">
        <Row label={t.tracking.caseLabel} value={demoCase.caseId} mono />
        <Row label={t.tracking.submittedLabel} value={t.tracking.submittedDate} />
        <Row label={t.tracking.expectedLabel} value={t.tracking.expectedDate} />
        <Row label={t.tracking.smsLabel} value={t.tracking.smsValue} mono icon={<MessageSquare size={14} />} />
      </dl>

      <div className="mb-10">
        <div className="text-xs uppercase tracking-widest mb-4" style={{ color: 'var(--ink-softer)' }}>
          {t.tracking.nextSteps}
        </div>
        <ul className="space-y-3">
          {t.tracking.stepsList.map((s, i) => (
            <li key={i} className="flex gap-3 text-[14px] leading-relaxed" style={{ color: 'var(--ink-soft)' }}>
              <Clock size={14} className="flex-shrink-0 mt-1" style={{ color: 'var(--ink-softer)' }} />
              <span>{s}</span>
            </li>
          ))}
        </ul>
      </div>

      <button onClick={onReset} className="hog-btn-ghost text-sm underline underline-offset-4 flex items-center gap-2">
        <ArrowRight size={14} /> {t.tracking.another}
      </button>
    </div>
  )
}

function StepLabel({ text }) {
  return (
    <div className="text-xs uppercase tracking-[0.2em] mb-6" style={{ color: 'var(--ink-softer)' }}>
      {text}
    </div>
  )
}

function Headline({ text }) {
  return (
    <h1 className="hog-serif text-[44px] md:text-[64px] leading-[0.95] mb-6 whitespace-pre-line" style={{ color: 'var(--ink)' }}>
      {text}
    </h1>
  )
}

function Row({ label, value, mono, icon }) {
  return (
    <div>
      <dt className="text-xs uppercase tracking-widest mb-2" style={{ color: 'var(--ink-softer)' }}>
        {label}
      </dt>
      <dd className={`text-[17px] flex items-center gap-2 ${mono ? 'hog-mono text-[15px]' : ''}`} style={{ color: 'var(--ink)' }}>
        {icon}
        {value}
      </dd>
    </div>
  )
}
